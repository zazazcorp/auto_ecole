-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 02 oct. 2019 à 17:46
-- Version du serveur :  10.3.16-MariaDB
-- Version de PHP :  7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `auto_ecole_dev`
--

-- --------------------------------------------------------

--
-- Structure de la table `dossier`
--

CREATE TABLE `dossier` (
  `id_dossier` int(10) NOT NULL,
  `date_depo` date DEFAULT NULL,
  `extrait` int(2) DEFAULT 0,
  `cnib` int(2) DEFAULT 0,
  `auto_parentale` int(2) DEFAULT 0,
  `quitance` int(2) DEFAULT 0,
  `ost` int(2) DEFAULT 0,
  `act_mariage` int(2) DEFAULT 0,
  `permi_provisoir` varchar(100) DEFAULT 'Aucune',
  `date_sorti` date DEFAULT NULL,
  `agence` varchar(100) DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  `eleve` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `dossier`
--

INSERT INTO `dossier` (`id_dossier`, `date_depo`, `extrait`, `cnib`, `auto_parentale`, `quitance`, `ost`, `act_mariage`, `permi_provisoir`, `date_sorti`, `agence`, `commentaire`, `eleve`) VALUES
(23, '2019-10-22', 0, 1, 0, 1, 0, 0, 'indisponible', NULL, 'BOBO', '', 12),
(24, NULL, 0, 0, 0, 0, 0, 0, '', NULL, '', '', 13);

-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

CREATE TABLE `eleve` (
  `id_eleve` int(10) NOT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `sexe` varchar(15) DEFAULT NULL,
  `dor` date NOT NULL,
  `categorie` varchar(30) DEFAULT NULL,
  `solde` float DEFAULT NULL,
  `forfait` varchar(100) DEFAULT NULL,
  `statut` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `eleve`
--

INSERT INTO `eleve` (`id_eleve`, `nom`, `prenom`, `contact`, `profession`, `adresse`, `dob`, `sexe`, `dor`, `categorie`, `solde`, `forfait`, `statut`) VALUES
(12, 'DABONE', 'Jean Claude', '898989898', 'MEDECIN', 'KARPALA', '1997-02-01', 'masculin', '2019-10-03', 'C', 125000, 'normal', 0),
(13, 'DOUAMBA', 'ALICE', '2121212121', 'Etudiante', '1200 lgts', '2017-08-12', 'feminin', '2019-10-09', 'C', 90000, 'special', 1),
(14, 'KABORE', 'Ousseni', '655567676', 'Informaticien', 'SAANBA', '2009-10-13', 'masculin', '2019-09-30', 'B', 125000, 'normal', 1);

-- --------------------------------------------------------

--
-- Structure de la table `examen`
--

CREATE TABLE `examen` (
  `id_examen` int(10) NOT NULL,
  `date_examen` date DEFAULT NULL,
  `examinateur` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `examen`
--

INSERT INTO `examen` (`id_examen`, `date_examen`, `examinateur`, `type`) VALUES
(1, '2019-09-11', 'OUEDRAOGO Issouf', 'crenau'),
(2, '2019-09-05', 'JEAN CLAUDE', 'code'),
(3, '2019-09-05', 'KABORE', 'conduite'),
(4, '2019-09-17', 'ALIMA KERE', 'code'),
(5, '2019-09-05', 'MME SERE', 'crenau');

-- --------------------------------------------------------

--
-- Structure de la table `examen_eleve`
--

CREATE TABLE `examen_eleve` (
  `id_examen_eleve` int(10) NOT NULL,
  `eleve` int(10) NOT NULL,
  `examen` int(10) NOT NULL,
  `resultat` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `examen_eleve`
--

INSERT INTO `examen_eleve` (`id_examen_eleve`, `eleve`, `examen`, `resultat`) VALUES
(31, 12, 4, 'admis'),
(32, 12, 1, 'ajourne'),
(33, 12, 3, 'admis'),
(34, 12, 4, 'ajourne');

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE `paiement` (
  `id_paiement` int(10) NOT NULL,
  `numero` varchar(200) DEFAULT NULL,
  `date_paiement` date NOT NULL,
  `somme` float DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `eleve` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `paiement`
--

INSERT INTO `paiement` (`id_paiement`, `numero`, `date_paiement`, `somme`, `type`, `eleve`) VALUES
(28, 'NÂ°593/2019', '2019-10-24', 25000, 'Frais de permis', 12),
(29, 'NÂ°590/2019', '2019-10-09', 100000, 'Frais de permis', 12),
(30, 'NÂ°580/2019', '2019-10-02', 85000, 'Frais de permis', 13),
(31, 'NÂ°580/2020', '2019-10-02', 119943, 'Frais de permis', 14);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(10) NOT NULL,
  `nom_user` varchar(100) DEFAULT NULL,
  `prenom_user` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `fonction` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `nom_user`, `prenom_user`, `username`, `password`, `fonction`) VALUES
(1, 'KABORE', 'Ousseni', 'kabore', 'admin', 'administrateur'),
(12, 'ZANNE', 'Issouf Zcorp', 'zcorp', 'zcorp', 'administrateur');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD PRIMARY KEY (`id_dossier`),
  ADD KEY `eleve` (`eleve`);

--
-- Index pour la table `eleve`
--
ALTER TABLE `eleve`
  ADD PRIMARY KEY (`id_eleve`);

--
-- Index pour la table `examen`
--
ALTER TABLE `examen`
  ADD PRIMARY KEY (`id_examen`);

--
-- Index pour la table `examen_eleve`
--
ALTER TABLE `examen_eleve`
  ADD PRIMARY KEY (`id_examen_eleve`),
  ADD KEY `eleve` (`eleve`),
  ADD KEY `examen` (`examen`);

--
-- Index pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`id_paiement`),
  ADD KEY `eleve` (`eleve`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `dossier`
--
ALTER TABLE `dossier`
  MODIFY `id_dossier` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT pour la table `eleve`
--
ALTER TABLE `eleve`
  MODIFY `id_eleve` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `examen`
--
ALTER TABLE `examen`
  MODIFY `id_examen` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `examen_eleve`
--
ALTER TABLE `examen_eleve`
  MODIFY `id_examen_eleve` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT pour la table `paiement`
--
ALTER TABLE `paiement`
  MODIFY `id_paiement` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `dossier`
--
ALTER TABLE `dossier`
  ADD CONSTRAINT `dossier_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);

--
-- Contraintes pour la table `examen_eleve`
--
ALTER TABLE `examen_eleve`
  ADD CONSTRAINT `examen_eleve_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`),
  ADD CONSTRAINT `examen_eleve_ibfk_2` FOREIGN KEY (`examen`) REFERENCES `examen` (`id_examen`);

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`eleve`) REFERENCES `eleve` (`id_eleve`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
