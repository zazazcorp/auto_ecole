<?php 	
include_once '../model/Paiement.class.php';

  if (isset($_POST['date']) AND isset($_POST['somme']) AND isset($_POST['type']) AND 
      isset($_POST['id']) AND isset($_POST['numero']) ) 
  {
  	$date = strip_tags(htmlspecialchars(trim($_POST['date'])));
	$somme = strip_tags(htmlspecialchars(trim($_POST['somme'])));
	$type = strip_tags(htmlspecialchars(trim($_POST['type'])));
	$numero = strip_tags(htmlspecialchars(trim($_POST['numero'])));
	$id = strip_tags(htmlspecialchars(trim($_POST['id'])));
	

	$data = array(
		'date_paiement' => $date,
		'somme' => $somme,
		'type' => $type,
		'numero' => $numero,
		'id' => $id);
	Paiement::register($data);

	echo '
	    <script language="javascript">
			swal("Réussi", "Paiement effectué avec succès", "success");			
		</script>';
  }
  else
  {
  	echo '
	    <script language="javascript">
			swal("Erreur", "Paiement Non effectué avec succès", "error");			
		</script>';
  }












 ?>