<?php 

	include_once '../model/Paiement.class.php';

	if ( isset($_GET['id_paiement'])) 
	{
		Paiement::supprimer($_GET['id_paiement']);
		header('location:../view/index.php?page=de_eleve&id_eleve='.$_GET['id_eleve']);
	}
	else
	{
		echo 'Id no vue';
	}




 ?>