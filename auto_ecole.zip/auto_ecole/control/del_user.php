<?php 

	include_once '../model/User.class.php';

	if ( isset($_POST['id_user'])) 
	{
		User::supprimer($_POST['id_user']);
		header('location:../view/index.php?page=utilisateur');
	}
	else
	{
		echo 'Id no vue';
	}




 ?>