<?php 
	include_once '../model/Eleve.class.php';

	if (isset($_POST['nom']) AND isset($_POST['prenom']) AND isset($_POST['contact']) AND 
      isset($_POST['profession']) AND isset($_POST['dob']) AND isset($_POST['dor'])
      AND isset($_POST['categorie']) AND isset($_POST['forfait']) AND isset($_POST['solde'])
      AND isset($_POST['sexe']) AND isset($_POST['adresse']) ) 
	  {
	  	$nom = strip_tags(htmlspecialchars(trim($_POST['nom'])));
		$prenom = strip_tags(htmlspecialchars(trim($_POST['prenom'])));
		$contact = strip_tags(htmlspecialchars(trim($_POST['contact'])));
		$profession = strip_tags(htmlspecialchars(trim($_POST['profession'])));
		$dob = strip_tags(htmlspecialchars(trim($_POST['dob'])));
		$dor = strip_tags(htmlspecialchars(trim($_POST['dor'])));
		$categorie = strip_tags(htmlspecialchars(trim($_POST['categorie'])));
		$forfait = strip_tags(htmlspecialchars(trim($_POST['forfait'])));
		$solde = strip_tags(htmlspecialchars(trim($_POST['solde'])));
		$sexe = strip_tags(htmlspecialchars(trim($_POST['sexe'])));
		$adresse = strip_tags(htmlspecialchars(trim($_POST['adresse'])));
		$statut = 1;
		

		$data = array(
			'nom' => $nom,
			'prenom' => $prenom,
			'contact' => $contact,
			'profession' => $profession,
			'dob' => $dob,
			'dor' => $dor,
			'categorie' => $categorie,
			'forfait' => $forfait,
			'solde' => $solde,
			'sexe' => $sexe,
			'adresse' => $adresse,
			'statut' => $statut);
		Eleve::register($data);

		echo '
		    <script language="javascript">
				swal("Réussi", "Elève ajouté avec succès", "success");
				window.location.href = "index.php?page=eleve";
			</script>';
	  }
	  else
	  {
	  	echo '
		     <script language="javascript">
				swal("Erreur!", "Données vides, veuillez remplir les champs !", "error");
			 </script>';
	  }



 ?>