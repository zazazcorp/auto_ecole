<?php 
	include_once '../model/User.class.php';
	User::logout();	
 ?>