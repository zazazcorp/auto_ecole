<?php 
    include_once'../model/Eleve.class.php'; 
    $eleve = Eleve::afficherOne($_GET['id_eleve']);
 ?>
<div class="btn btn-primary btn-lg"><?=$eleve[0]->nom.' '.$eleve[0]->prenom;?></div>
<form role="form" id="formulaire_up">
    <div class="col-lg-6">
        <div class="form-group">
            <label>Nom</label>
            <input id="nom_save" type="text" class="form-control" value="<?=$eleve[0]->nom; ?>" required>
            
        </div>
        <div class="form-group">
            <label>Prénom</label>
            <input id="prenom_save" type="text" class="form-control" value="<?=$eleve[0]->prenom; ?>" required>
        </div>
        <div class="form-group">
            <label>Contact</label>
            <input id="contact_save" type="text" class="form-control" value="<?=$eleve[0]->contact; ?>" required>
        </div>
        <div class="form-group">
            <label>Profession</label>
            <input id="profession_save" type="text" class="form-control" value="<?=$eleve[0]->profession; ?>" required>
        </div>
        <div class="form-group">
            <label>Adresse</label>
            <input id="adresse_save" type="text" class="form-control" value="<?=$eleve[0]->adresse; ?>" required>
        </div>
        <div class="form-group">
            <label>Date de Naissance</label>
            <input id="dob_save" type="date" class="form-control" value="<?=$eleve[0]->dob; ?>" required>                                        
        </div>                                          
    </div>

    <div class="col-lg-6">
        <div class="form-group">
            <label>Date Inscription</label>
            <input id="dor_save" type="date" class="form-control" value="<?=$eleve[0]->dor; ?>" required>
        </div>
        <div class="form-group">
            <label>Catégorie Permis</label>
            <select id="categorie_save" class="form-control" required>
               <option selected value="<?=$eleve[0]->categorie; ?>"><?=$eleve[0]->categorie; ?></option>
               <option  value="A">A</option>
               <option  value="B">B</option>
               <option  value="C">C</option>
               <option  value="D">D</option>
               <option  value="E">E</option>
               
            </select>
        </div>                    
        <div class="form-group">
            <label>Forfait</label>
            <input id="forfait_save" type="text" class="form-control" value="<?=$eleve[0]->forfait; ?>" required>
        </div>
        <div class="form-group">
            <label>Solde Forfait</label>
            <input id="solde_save" type="number" class="form-control" value="<?=$eleve[0]->solde; ?>" required>
        </div> 
        <div class="form-group">
            <label>Statut</label>
            <input id="statut_save" type="number" class="form-control" value="<?=$eleve[0]->statut; ?>" required>
        </div>                                   
        <div class="form-group">
            <label>Sexe</label>
            <select id="sexe_save" class="form-control" required>
               <option selected value="<?=$eleve[0]->sexe; ?>"><?=$eleve[0]->sexe; ?></option>
               <option value="masculin">masculin</option>
               <option value="feminin">feminin</option>
            </select>
        </div>
        <div class="form-group">
            <label>ID</label>
            <input id="id_eleve" type="number" class="form-control" value="<?=$eleve[0]->id_eleve; ?>" readonly>
        </div>                                            
        <div class="form-group">
            <button type="submit" class="btn-lg btn-primary">Modifier</button>        
        </div>                         
  </div>                                           
</form>
<div id="comment"></div>

<script type="text/javascript">
    // Save User 
    $('#formulaire_up').submit( function()
        {
              var nom = $('#nom_save').val();
              var prenom = $('#prenom_save').val();
              var contact = $('#contact_save').val();
              var profession = $('#profession_save').val();
              var adresse = $('#adresse_save').val();
              var dob = $('#dob_save').val();
              var dor = $('#dor_save').val();
              var categorie = $('#categorie_save').val();
              var forfait = $('#forfait_save').val();
              var solde = $('#solde_save').val();
              var sexe = $('#sexe_save').val();
              var id = $('#id_eleve').val();
              var statut = $('#statut_save').val();
              
                $.post('../control/up_eleve.php', {nom:nom,prenom:prenom,contact:contact,profession:profession,adresse:adresse,dob:dob,dor:dor,categorie:categorie,
                  forfait:forfait,solde:solde,sexe:sexe,id:id,statut:statut}, function(response)
                {
                  $('#comment').html(response);                   
                });

             
                //swal("Erreur!", "Les Mots de passe ne correspondent pas !", "error");
                //alert('Les mots de passe ne correspondent pas !!!');
              
           return false;         

        });

</script>