<?php include_once '../model/Eleve.class.php' ; ?>

<div class="row">
    <div class="panel panel-default">
        <div class="panel-body">
            <ul class="nav nav-tabs">
                <li ><a href="#ajouter" data-toggle="tab"><h4>Ajouter</h4></a>
                </li>
                <li class="active"><a href="#liste" data-toggle="tab"><h4>Liste en Cours</h4></a>
                </li>
                <li><a href="#listeP" data-toggle="tab"><h4>Liste Permis</h4></a>
                </li>                                                
            </ul>
            <div class="tab-content">
                <!-- Tab Ajouter user -->
                <div class="tab-pane fade" id="ajouter">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Ajouter un nouvel Elève
                        </div>
                        <div class="panel-body">
                            <form role="form" id="formulaire_save">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Nom</label>
                                        <input id="nom_save" type="text" class="form-control" placeholder="Nom" required>
                                        
                                    </div>
                                    <div class="form-group">
                                        <label>Prénom</label>
                                        <input id="prenom_save" type="text" class="form-control" placeholder="Prénom" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Contact</label>
                                        <input id="contact_save" type="text" class="form-control" placeholder="Numéro" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Profession</label>
                                        <input id="profession_save" type="text" class="form-control" placeholder="Profession" >
                                    </div>
                                    <div class="form-group">
                                        <label>Adresse</label>
                                        <input id="adresse_save" type="text" class="form-control" placeholder="Adresse">
                                    </div>
                                    <div class="form-group">
                                        <label>Date de Naissance</label>
                                        <input id="dob_save" type="date" class="form-control" >                                        
                                    </div>                                          
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Date Inscription</label>
                                        <input id="dor_save" type="date" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Catégorie Permis</label>
                                        <select id="categorie_save" class="form-control" required>
                                           <option  value="A">A</option>
                                           <option  value="B">B</option>
                                           <option  value="C">C</option>
                                           <option selected value="D">D</option>
                                           <option  value="E">E</option>
                                           
                                        </select>
                                    </div>                    
                                    <div class="form-group">
                                        <label>Forfait</label>
                                        <select id="forfait_save" class="form-control" required>
                                           <option selected  value="normal">Tarif Normal</option>
                                           <option  value="special">Tarif Spécial</option>                       
                                        </select>
                                        
                                    </div>
                                    <div class="form-group">
                                        <label>Solde Forfait</label>
                                        <input id="solde_save" type="number" class="form-control" placeholder="Solde du forfait" required>
                                    </div>                                    
                                    <div class="form-group">
                                        <label>Sexe</label>
                                        <select id="sexe_save" class="form-control" required>
                                           <option selected value="masculin">masculin</option>
                                           <option value="feminin">feminin</option>
                                        </select>
                                    </div>                                                            
                                    <div class="form-group">
                                        <button type="submit" class="btn-lg btn-primary">Ajouter</button>        
                                    </div>                         
                              </div>                                           
                            </form>                           
                        </div>
                    </div>
                    
                </div>
                <!-- Tab Liste Users -->
                <div class="tab-pane fade in active" id="liste">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Tous les Elèves en Cours
                            <a href="../public/pdf/eleve.php?ind=cours" target="_blank" class="btn btn-primary">Imprimer Liste Simple</a>
                            <a href="../public/pdf/paiement.php?ind=solde" target="_blank" class="btn btn-success">
                            Scolarité Soldés</a>
                            <a href="../public/pdf/paiement.php?ind=redevable" target="_blank" class="btn btn-warning">
                            Scolarité Redevables</a>
                            <a href="../public/pdf/paiement.php?ind=impaye" target="_blank" class="btn btn-danger">
                            Scolarité Impayés</a>
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Nom</th>
                                        <th>Prénoms</th>
                                        <th>Profession</th>
                                        <th>Catégorie</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $eleves = Eleve::afficherCours(); $i=1; ?>
                                    <?php foreach ($eleves as $eleve) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$i; ?></td>
                                        <td><?=$eleve->nom; ?></td>
                                        <td><?=$eleve->prenom; ?></td>
                                        <td><?=$eleve->profession; ?></td>
                                        <td><?=$eleve->categorie; ?></td>
                                        <td class="center">
                                            <!-- Modal must dynam and script -->
                                            <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                                            <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod'.$i;?>">
                                              <span class="fa fa-trash"></span>
                                            </button>
                                            <?php } ?>

                                            <!-- Modal -->
                                            <div class="modal fade" id="<?='mod'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod'.$i;?>" aria-hidden="true">
                                              <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <h5 class="modal-title" id="<?='#mod'.$i;?>">
                                                      Supprimer <b><?=$eleve->nom.' '.$eleve->prenom.' '.$eleve->id_eleve; ?></b>
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                  </div>
                                                  <form method="post" action="../control/del_eleve.php">
                                                      <div class="modal-body">                           
                                                        <input type="hidden" name="id_eleve" value="<?=$eleve->id_eleve;?>">
                                                        <button class="btn btn-danger">
                                                        <h3>
                                                            Voulez vous vraiment supprimer cet utilisateur ?                                                 
                                                        </h3>
                                                        </button>                                      
                                                      </div>
                                                      <div class="modal-footer">                           
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                                        <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                                                      </div>                                                      
                                                  </form>
                                                </div>
                                              </div>
                                            </div>                                            
                                            <a title="Modifier" class="btn btn-success" href="index.php?page=up_eleve&id_eleve=<?=$eleve->id_eleve;?>">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=de_eleve&id_eleve=<?=$eleve->id_eleve;?>">
                                              <span class="fa fa-table"></span>
                                            </a>
                                            <a title="Examen" class="btn btn-warning" href="index.php?page=eleve_examen&id_eleve=<?=$eleve->id_eleve ; ?>">
                                              <span class="fa fa-check"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $i++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>
                <!-- Tab Liste Permis Provisoir -->
                <div class="tab-pane fade" id="listeP">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Les Elèves qui ont Obtenu le Permis Provisoir
                            <a href="../public/pdf/eleve.php?ind=permis" target="_blank" class="btn btn-warning">Imprimer</a>
                        </div>
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>N°</th>
                                        <th>Nom</th>
                                        <th>Prénoms</th>
                                        <th>Profession</th>
                                        <th>Catégorie</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $pupil = Eleve::afficherStatut(); $i=1; ?>
                                    <?php foreach ($pupil as $pup) : ?>
                                    <tr class="odd gradeX">
                                        <td><?=$i; ?></td>
                                        <td><?=$pup->nom; ?></td>
                                        <td><?=$pup->prenom; ?></td>
                                        <td><?=$pup->profession; ?></td>
                                        <td><?=$pup->categorie; ?></td>
                                        <td class="center">
                                            <!-- Modal must dynam and script -->
                                            <?php if ($_SESSION['fonction'] == 'administrateur') {  ?>
                                            <button title="Supprimer" type="button" class="btn btn-danger" data-toggle="modal" data-target="<?='#mod2'.$i;?>">
                                              <span class="fa fa-trash"></span>
                                            </button>
                                            <?php } ?>

                                            <!-- Modal -->
                                            <div class="modal fade" id="<?='mod2'.$i;?>" tabindex="-1" role="dialog" aria-labelledby="<?='#mod2'.$i;?>" aria-hidden="true">
                                              <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <h5 class="modal-title" id="<?='#mod2'.$i;?>">
                                                      Supprimer <b><?=$pup->nom.' '.$pup->prenom.' '.$pup->id_eleve; ?></b>
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                  </div>
                                                  <form method="post" action="../control/del_eleve.php">
                                                      <div class="modal-body">                           
                                                        <input type="hidden" name="id_eleve" value="<?=$pup->id_eleve;?>">
                                                        <button class="btn btn-danger">
                                                        <h3>
                                                            Voulez vous vraiment supprimer cet utilisateur ?                                                 
                                                        </h3>
                                                        </button>                                      
                                                      </div>
                                                      <div class="modal-footer">                           
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">NON</button>
                                                        <button type="submit" name="submit" class="btn btn-primary">OUI</button>
                                                      </div>                                                      
                                                  </form>
                                                </div>
                                              </div>
                                            </div>                                            
                                            <a title="Modifier" class="btn btn-success" href="index.php?page=up_eleve&id_eleve=<?=$pup->id_eleve;?>">
                                              <span class="fa fa-pencil"></span>
                                            </a>
                                            <a title="Détail" class="btn btn-primary" href="index.php?page=de_eleve&id_eleve=<?=$pup->id_eleve;?>">
                                              <span class="fa fa-table"></span>
                                            </a>
                                            <a title="Examen" class="btn btn-warning" href="index.php?page=eleve_examen&id_eleve=<?=$pup->id_eleve ; ?>">
                                              <span class="fa fa-check"></span>
                                            </a>
                                        </td>                                        
                                    </tr>
                                    <?php $i++; ?> 
                                    <?php endforeach; ?>                                      
                                </tbody>
                            </table>                            
                        </div>
                    </div>                    
                </div>

            </div>            
        </div>        
    </div>    
</div>
<div id="comment"></div>

<script type="text/javascript">
    // Save User 
    $('#formulaire_save').submit( function()
        {
              var nom = $('#nom_save').val();
              var prenom = $('#prenom_save').val();
              var contact = $('#contact_save').val();
              var profession = $('#profession_save').val();
              var adresse = $('#adresse_save').val();
              var dob = $('#dob_save').val();
              var dor = $('#dor_save').val();
              var categorie = $('#categorie_save').val();
              var forfait = $('#forfait_save').val();
              var solde = $('#solde_save').val();
              var sexe = $('#sexe_save').val();
              
                $.post('../control/reg_eleve.php', {nom:nom,prenom:prenom,contact:contact,profession:profession,adresse:adresse,dob:dob,dor:dor,categorie:categorie,
                  forfait:forfait,solde:solde,sexe:sexe}, function(response)
                {
                  $('#comment').html(response);                   
                });

             
                //swal("Erreur!", "Les Mots de passe ne correspondent pas !", "error");
                //alert('Les mots de passe ne correspondent pas !!!');
              
           return false;         

        });

</script>