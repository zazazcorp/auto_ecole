<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	
	<title>Liste des élèves</title>
   
</head>
<body> 
<?php 

   include_once("../../model/Examen.class.php");
   include_once("../../model/Eleve.class.php"); 
   $examens = Examen::afficherParticipantExamenOne($_GET['id_examen']);      


    ob_start();
    require("../vendor/fpdf/fpdf.php");
	
	$pdf = new FPDF('P','mm','A4'); 
    // $pdf = new FPDF('P','mm',array(195,291));
	$pdf->SetAutoPageBreak('On'); 
	$pdf->AddPage();
	// Image de fond d'ecran
	// $pdf->Image('../fpdf/carte.jpg', 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight());
	$pdf->SetTextColor(23);
	$pdf->SetFont('times','',8);
	// 	$pdf->text(4, 5, utf8_decode("largeur, hauteur"));	 
	$pdf->text(10, 35 , utf8_decode("GLOIRE AUTO ECOLE")); 
	
	
	$pdf->SetFont('times','B',15);
	$pdf->SetY(50); 
	$pdf->SetX(30);
	$pdf->MultiCell($pdf->GetPageWidth()-70,10,utf8_decode(" Liste des élèves ayant participé à cet Examen"), 1, 'C', false);
	
	$pdf->SetFont('times','',10);		
		
	$pdf->SetFillColor(224,235,255);
	$pdf->SetFont('times','B',11);
	$w = array(8, 35, 45, 17, 20, 63,15);
	$pdf->SetY(70); 
	$pdf->SetX(5); 
	$pdf->Cell($w[0],10,utf8_decode("N°"),1,0,'C',true);
	$pdf->Cell($w[1],10,utf8_decode("Nom"),1,0,'C',true);
	$pdf->Cell($w[2],10,utf8_decode("Prenom"),1,0,'C',true);
	$pdf->Cell($w[3],10,utf8_decode("Examen"),1,0,'C',true);
	$pdf->Cell($w[4],10,utf8_decode("Date"),1,0,'C',true); 
	$pdf->Cell($w[5],10,utf8_decode("Examinateur"),1,0,'C',true);
	$pdf->Cell($w[6],10,utf8_decode("Résultat"),1,0,'C',true);    
    $cp = 1;
    $x = 80;

    foreach ($examens as $examen ) :
    	$pdf->SetFont('times','',10);
		$pdf->SetY($x);
		$pdf->SetX(5);  
		$pdf->Cell($w[0],10,utf8_decode($cp),1,0,'C',false);
		$pdf->Cell($w[1],10,utf8_decode($examen->nom),1,0,'C',false);
		$pdf->Cell($w[2],10,utf8_decode($examen->prenom),1,0,'C',false);
		$pdf->Cell($w[3],10,utf8_decode($examen->type),1,0,'C',false);
		$pdf->Cell($w[4],10,utf8_decode($examen->date_examen),1,0,'C',false); 
		$pdf->Cell($w[5],10,utf8_decode($examen->examinateur),1,0,'C',false);
		$pdf->Cell($w[6],10,utf8_decode($examen->resultat),1,0,'C',false);		
		$cp+=1;
		$x+=10;
		if ($x > 270) 
		{
			$pdf->AddPage();
			$x = 10;
		}
       
    endforeach;

	//Corps 
	//$pdf->SetFont('Arial','',11);
	$pdf->SetFont('times','', 11); 
	$pdf->SetTextColor(0);	 

	$pdf->Output();
	// $pdf->Output(F,'../filename2.pdf'); // ça marche aussi
	ob_end_flush(); 
  
?>
 
</body>
</html>
