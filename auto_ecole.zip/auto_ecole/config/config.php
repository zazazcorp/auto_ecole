<?php 

/*
 * Les Variables globales pour configurer le système 
 * Les informations sur votre Auto Ecole 
 */

$config = array(
    'NOM' => 'Gloire Auto Ecole',
    'NUMERO' => '+(226)25-35-55-45',
    'EMAIL' => 'monautoecole@gmail.com',
    'LOCATION' => 'Sect 30, Saaba Avenue X',
    'ADRESSE' => '',    
);



?>